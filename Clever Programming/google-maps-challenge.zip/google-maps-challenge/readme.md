## Design Link

https://www.figma.com/file/HuauCfrLa39DV0lK76LLZb/Google-Maps?node-id=0%3A2

## Google Maps API Key

AIzaSyCcwazb-T7zvceyA4VLWVB-eXvwj-XEUIA

**WARNING**
DO NOT SHARE IT WITH ANYONE

## FontAwesome Link

https://kit.fontawesome.com/c939d0e917.js

